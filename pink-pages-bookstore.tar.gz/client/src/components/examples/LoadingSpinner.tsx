import LoadingSpinner from '../LoadingSpinner';

export default function LoadingSpinnerExample() {
  return <LoadingSpinner />;
}
